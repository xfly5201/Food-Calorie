import Foundation

import CoreData

// 数据库管理入口
class CoreDataStack : ObservableObject{
    
    private let persistentContainer: NSPersistentContainer // 保存数据库入口的容器
    
    var managedObjectContext: NSManagedObjectContext { // NSManagedObjectContext：注入到环境的数据库入口的类型
        persistentContainer.viewContext // managedObjectContext：访问数据库的入口
    }
    
    init(modelName: String){
        persistentContainer = {
            let container = NSPersistentContainer(name: modelName)
            container.loadPersistentStores { _, error in
                if let error = error{
                    print(error)
                }
            }
            return container
        }()
    }
    
    func save(){
        // 数据库入口的数据发生变化的话就保存
        guard managedObjectContext.hasChanges else {return}
        do{
            try managedObjectContext.save()
        }catch{
            print(error)
        }
    }
}
