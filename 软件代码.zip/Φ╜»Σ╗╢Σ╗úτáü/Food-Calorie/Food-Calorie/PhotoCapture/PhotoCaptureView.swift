import SwiftUI

import SwiftUI
import UIKit
import Vision
import CryptoKit
import Photos
import Foundation


// 实现食物卡路里的识别
struct PhotoCaptureView: View {
    
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var alertType: addAlertType?
    @State private var MoreInfoAlert: Bool = false
    @State private var MoreInfoSheet: Bool = false
    
    @State private var isCameraPresented = false // 控制相机视图的展示状态
    @State private var selectedImage: UIImage? // 存储选择的图片
    @State private var classificationResult:  (foodName: String, probability: Float)? // 食物名和概率
    @State private var classificationInfo:  String?// 分类结果
    @State private var foodInfo = FoodInfo() // 食物信息
    @State private var hasChoose: Bool = false
    
    @State private var imagePickerSourceType = UIImagePickerController.SourceType.camera // 图片选择源类型
    
    let appid = "20240206001960665"
    let key = "S2ejCbV6bYD6d4EQbvtC"
    
    let foodList = ["apple pie", "Pork Ribs", "baklava", "carpaccio", "beef tartare", "beet salad", "Fritter", "bibimbap", "bread pudding", "breakfast burrito", "toast", "caesar salad", "cannoli", "caprese salad", "carrot cake", "ceviche", "cheese plate", "cheesecake", "chicken curry", "chicken quesadilla", "chicken wings", "chocolate cake", "chocolate mousse", "churros", "clam chowder", "club sandwich", "crab cakes", "creme brulee", "ham and cheese sandwich", "cup cakes", "deviled eggs", "donuts", "dumplings", "edamame", "eggs benedict", "escargots", "falafel", "filet mignon", "fish and chips", "foie gras", "french fries", "french onion soup", "french toast", "calamari", "fried rice", "frozen yogurt", "garlic bread", "gnocchi", "greek salad", "grilled cheese sandwich", "grilled salmon", "guacamole", "gyoza", "hamburger", "hot and sour soup", "hot dog", "huevos rancheros", "hummus", "ice cream", "lasagna", "lobster bisque", "lobster roll", "macaroni and cheese", "macarons", "miso soup", "mussels", "nachos", "omelette", "onion rings", "oysters", "pad thai", "paella", "pancakes", "panna cotta", "peking duck", "pho", "pizza", "pork chop", "poutine", "prime rib", "pulled pork sandwich", "ramen", "ravioli", "red velvet cake", "risotto", "samosa", "sashimi", "scallops", "seaweed salad", "shrimp and grits", "spaghetti bolognese", "spaghetti", "spring rolls", "steak", "strawberry shortcake", "sushi", "tacos", "octopus", "tiramisu", "tuna", "waffles"]


    var body: some View {
        VStack {
            
            Spacer()
            
            // 显示选择的图片
            if let selectedImage = selectedImage {
                Image(uiImage: selectedImage)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .shadow(radius: 10)
            }else {
                Text("点击下方按钮拍摄图片")
                    .font(.headline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            VStack{
                HStack{
                    Text("食物名："+foodInfo.foodChineseName)
                        .padding()
                    Spacer()
                    Text("置信度：\((classificationResult?.probability ?? 0) * 100, specifier: "%.2f")%")
                        .padding()
                }
                HStack{
                    Text("卡路里(卡)："+String(foodInfo.foodCalories))
                        .padding()
                    Spacer()
                    Text("单位质量(g)："+String(foodInfo.foodWeight))
                        .padding()
                }
                HStack{
                    Button {
                        // 判断是否有图片信息
                        if hasChoose{
                            addFoodInfo()
                            alertType = .success
                        }
                        else{
                            alertType = .failure
                        }
                        
                    } label: {
                        ZStack{
                            Text("加入日记")
                        }
                    }
                    .buttonStyle(.bordered)
                    .alert(item: $alertType) { alertType in
                        switch alertType {
                        case .success:
                            return Alert(title: Text("添加成功"), message: Text("可以在食物日记看到食物信息"), dismissButton: .default(Text("好")))
                        case .failure:
                            return Alert(title: Text("添加失败"), message: Text("请拍摄图片识别"), dismissButton: .default(Text("好")))
                        }
                    }
                    
                    Spacer()
                    
                    Button {
                        if hasChoose{
                            MoreInfoSheet = true
                        }
                        else{
                            MoreInfoAlert = true
                        }
                    } label: {
                        Text("详细信息")
                    }
                    .buttonStyle(.bordered)
                    .sheet(isPresented: $MoreInfoSheet, content: {
                        VStack{
                            Text(foodMoreInfo())
                        }
                        .padding()
                    })
                    .alert(isPresented: $MoreInfoAlert, content: {
                        Alert(title: Text("查询失败"), message: Text("请拍摄图片识别"), dismissButton: .default(Text("好")))
                    })
                    
                    
                }
                .padding()
            }
            .padding()
            
            // 从相机拍摄按钮
            Button(action: {
                imagePickerSourceType = .camera
                isCameraPresented = true
            }) {
                HStack {
                    Image(systemName: "camera")
                    Text("拍摄照片")
                }
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding()
                .foregroundColor(.white)
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                .cornerRadius(40)
                .font(.headline)
            }
            .padding(.bottom, 20)
            
            
            
        
        }
        .sheet(isPresented: $isCameraPresented) {
            CameraView(selectedImage: $selectedImage, isCameraPresented: $isCameraPresented, sourceType: $imagePickerSourceType)
                .onDisappear {
                    if let selectedImage = selectedImage {
                        classifyImage(image: selectedImage)
                    }
                }
        }
        .padding()
    }
    
    // 添加食物信息到日记
    private func addFoodInfo(){
        
        let foodinfo = FoodDiary(context: viewContext)
        foodinfo.name = foodInfo.foodChineseName
        foodinfo.calorie = foodInfo.foodCalories
        foodinfo.dairy = getTime()
        foodinfo.foodInfo=foodMoreInfo()
        foodinfo.infoId = UUID()
        do {
            try viewContext.save()
            print("食物信息已添加")
        } catch {
            let nsError = error as NSError
            fatalError("发生错误 \(nsError), \(nsError.userInfo)")
        }
        
    }
    
    // 获得当前时间
    private func getTime() -> String{
        let now = Date()

        // 创建一个日期格式器
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // 设置格式为年-月-日

        // 使用日期格式器格式化当前日期
        let dateString = dateFormatter.string(from: now)

        // 打印结果
        return dateString
        
    }
    
    // 获得详细的食物信息
    private func foodMoreInfo() ->String{
        let foodInfoString = """
        
        食物名称：\(foodInfo.foodChineseName)
        
        卡路里：\(foodInfo.foodCalories) 卡
        
        重量：\(foodInfo.foodWeight) 克
        
        总脂肪：\(foodInfo.foodFatTotal) 克
        
        饱和脂肪：\(foodInfo.foodFatSaturated) 克
        
        蛋白质：\(foodInfo.foodProtein) 克
        
        钾：\(foodInfo.foodPotassium) 毫克
        
        钠：\(foodInfo.foodSodium) 毫克
        
        胆固醇：\(foodInfo.foodCholesterol) 毫克
        
        纤维：\(foodInfo.foodFiber) 克
        
        糖：\(foodInfo.foodSugar) 克
        
        （每100克的含量）
        
        """
        return foodInfoString
    }


    
    // 图片分类处理
    private func classifyImage(image: UIImage) {
        guard let buffer = image.toCVPixelBuffer() else {
            classificationInfo = "图像处理错误。"
            return
        }

        // 使用 Core ML 模型进行分类
        do {
            let model = try food101(configuration: MLModelConfiguration())
            let visionModel = try VNCoreMLModel(for: model.model)
            let request = VNCoreMLRequest(model: visionModel) { request, error in
                if let error = error {
                    self.classificationInfo = "预测错误：\(error)"
                    return
                }

                // 解析预测结果
                guard let results = request.results as? [VNCoreMLFeatureValueObservation],
                      let firstResult = results.first,
                      let multiArray = firstResult.featureValue.multiArrayValue else {
                    self.classificationInfo = "没有结果或结果类型不符"
                    return
                }

                // 找到最大概率的分类
                let (maxIndex, maxValue) = self.argmax(multiArray)
                DispatchQueue.main.async {
                    let foodName = (maxIndex < self.foodList.count) ? self.foodList[maxIndex] : "未知"
                    self.classificationResult = (foodName, maxValue)
                    self.giveInfo(foodName: foodName)
                    self.translate(query: foodName, from: "en", to: "zh")
                    self.hasChoose = true
                }
            }

            // 执行分类请求
            let handler = VNImageRequestHandler(cvPixelBuffer: buffer)
            try handler.perform([request])
        } catch {
            classificationInfo = "预测过程中出错：\(error)"
        }
    }


    // 寻找最大概率的辅助函数
    private func argmax(_ multiArray: MLMultiArray) -> (Int, Float) {
        var maxIndex = 0
        var maxValue: Float = 0.0
        for i in 0..<multiArray.count {
            let value = multiArray[i].floatValue
            if value > maxValue {
                maxValue = value
                maxIndex = i
            }
        }
        return (maxIndex, maxValue)
    }
    
    // 调用API获取卡路里信息
    private func giveInfo(foodName: String) {
        // 将下划线替换为空格，以符合API的期望格式
        let formattedFoodName = foodName.replacingOccurrences(of: "_", with: " ")

        // 确保查询字符串进行URL编码
        guard let query = formattedFoodName.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://api.calorieninjas.com/v1/nutrition?query=" + query) else {
            print("无效的查询字符串")
            return
        }

        var request = URLRequest(url: url, timeoutInterval: Double.infinity)
        request.addValue("gwsjHbdiPdCR02otpYoahg==AlTZFeMQ4pwfB4mV", forHTTPHeaderField: "X-Api-Key")
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("网络请求错误: \(error)")
                    return
                }
                guard let data = data else {
                    print("未接收到数据")
                    return
                }

                // 使用 JSONDecoder 解析 JSON 数据
                let decoder = JSONDecoder()
                do {
                    let nutritionResponse = try decoder.decode(NutritionResponse.self, from: data)
                    if let firstItem = nutritionResponse.items.first {
                        self.foodInfo.foodName=firstItem.name
                        self.foodInfo.foodCalories=firstItem.calories
                        self.foodInfo.foodWeight=firstItem.serving_size_g
                        self.foodInfo.foodFatTotal=firstItem.fat_total_g
                        self.foodInfo.foodFatSaturated=firstItem.fat_saturated_g
                        self.foodInfo.foodProtein=firstItem.protein_g
                        self.foodInfo.foodPotassium=firstItem.potassium_mg
                        self.foodInfo.foodSodium=firstItem.sodium_mg
                        self.foodInfo.foodProtein=firstItem.protein_g
                        self.foodInfo.foodCholesterol=firstItem.cholesterol_mg
                        self.foodInfo.foodFiber=firstItem.fiber_g
                        self.foodInfo.foodSugar=firstItem.sugar_g
                    } else {
                        print("未找到食物信息")
                    }
                } catch {
                    print("解析错误: \(error)")
                }
            }
        }
        task.resume()
    }

    // 英文翻译成中文
    func MD5(string: String) -> String {
        let digest = Insecure.MD5.hash(data: string.data(using: .utf8) ?? Data())
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }

    func createSign(query: String, salt: String) -> String {
        let signString = "\(appid)\(query)\(salt)\(key)"
        return MD5(string: signString)
    }

    func translate(query: String, from: String, to: String) {
        let salt = String(Int.random(in: 10000..<99999))
        let sign = createSign(query: query, salt: salt)
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "https://fanyi-api.baidu.com/api/trans/vip/translate?q=\(encodedQuery)&from=\(from)&to=\(to)&appid=\(appid)&salt=\(salt)&sign=\(sign)"

        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error: \(error)")
                    return
                }
                if let data = data {
                    do {
                        let translationResponse = try JSONDecoder().decode(TranslationResponse.self, from: data)
                        if let firstResult = translationResponse.trans_result.first {
                            print("翻译结果: \(firstResult.dst)")
                            self.foodInfo.foodChineseName=firstResult.dst
                        }
                    } catch {
                        print("解析JSON时出错: \(error)")
                    }
                }
            }.resume()
        }
    }

}
#Preview {
    PhotoCaptureView()
}
