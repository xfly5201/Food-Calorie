import SwiftUI

struct FoodDiaryView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @SectionedFetchRequest<String?, FoodDiary>(
        sectionIdentifier: \.dairy,
        sortDescriptors:[
            NSSortDescriptor(keyPath: \FoodDiary.dairy, ascending: false)
        ]
        
    )var diaryInfo
    
    var body: some View {
        NavigationView{
            
            VStack{
                List(diaryInfo){ section in
                    Section{
                        ForEach(section){foodInfo in
                            NavigationLink(destination: moreFoodInfoView(foodinfo: foodInfo)){
                                HStack{
                                    Text(foodInfo.name ?? "")
                                }
                            }
                        }
                        .onDelete(perform: { indexSet in
                            guard let index = indexSet.first else {return}
                            viewContext.delete(section[index])
                            do {
                                try viewContext.save()
                            } catch {
                                let nsError = error as NSError
                                fatalError("删除错误  \(nsError), \(nsError.userInfo)")
                            }
                        })
                    }header:{
                        Text(section.id ?? "")
                    }
                }
            }
            
        }
    }
}

#Preview {
    FoodDiaryView()
}
