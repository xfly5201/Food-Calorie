import SwiftUI

struct moreFoodInfoView: View {
    
    var foodinfo: FoodDiary
    
    var body: some View {
        VStack{
            Text(foodinfo.foodInfo ?? "")
        }
    }
}

