import SwiftUI

struct XianwView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日纤维摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("25 或 38克")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    纤维是一种碳水化合物，人体无法消化。它有助于维持肠道健康，控制血糖水平，降低胆固醇。男女的每日摄入量不同，女性25克，男性38克。
                    
                    摄入过多会导致胃肠不适、腹胀和吸收其他营养素的困难。
                    
                    摄入不足会导致便秘、较高的心脏病和2型糖尿病风险增加。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    XianwView()
}
