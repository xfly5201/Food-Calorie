import SwiftUI

struct ZongzfView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日总脂肪摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("61克")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    脂肪是三大营养素之一，提供能量，支持细胞生长，保护器官，帮助吸收一些营养素，参与激素生产。总脂肪包括饱和脂肪、不饱和脂肪和反式脂肪。脂肪是重要的能量来源，也是维持细胞结构和吸收脂溶性维生素必需的。总热量的20%-35%来自脂肪。对于一个日常能量需求为2000千卡的成年人来说，每日总脂肪摄入量推荐在44克到78克之间。
                    
                    摄入过多尤其是饱和脂肪和反式脂肪，会引起心血管疾病、肥胖、糖尿病等健康问题
                    
                    摄入不足可能导致维生素吸收不良、激素水平失衡等问题。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    ZongzfView()
}
