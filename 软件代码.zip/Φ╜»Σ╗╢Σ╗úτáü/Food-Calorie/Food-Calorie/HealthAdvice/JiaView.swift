import SwiftUI

struct JiaView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日钾摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("4700毫克")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    钾是一种重要的矿物质，对于维持正常的血压、神经信号传递、肌肉收缩和心脏功能至关重要。维持正常的神经和肌肉功能，调节心跳，帮助维持水分平衡。
                    
                    摄入过多可能导致心脏问题，特别是在肾功能不全时。
                    
                    摄入不足可能导致高血压、肌肉痉挛。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    JiaView()
}
