import SwiftUI

struct HealthAdviceView: View {
    var body: some View {
        NavigationView{
            
            VStack{
                
                NavigationLink(destination: KallView()) {
                    HStack {
                        Text("卡路里")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: ZongzfView()) {
                    HStack {
                        Text("总脂肪")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: BaohzfView()) {
                    HStack {
                        Text("饱和脂肪")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: DanbzView()) {
                    HStack {
                        Text("蛋白质")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: JiaView()) {
                    HStack {
                        Text("钾")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: NaView()) {
                    HStack {
                        Text("钠")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: DangcView()) {
                    HStack {
                        Text("胆固醇")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: XianwView()) {
                    HStack {
                        Text("纤维")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: TangView()) {
                    HStack {
                        Text("糖")
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
            }
            
        }
    }
}

#Preview {
    HealthAdviceView()
}
