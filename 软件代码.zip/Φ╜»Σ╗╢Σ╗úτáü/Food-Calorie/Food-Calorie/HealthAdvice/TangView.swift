import SwiftUI

struct TangView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日糖摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("25-50克")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    糖是一种简单的碳水化合物，可提供快速能量。但是，过多摄入添加糖与多种健康问题有关。提供快速能量。
                    
                    摄入过多会导致体重增加、糖尿病、心脏病等问题
                    
                    尽管糖本身对于身体没有必需的营养作用，但适量的糖摄入对于享受饮食和提供即时能量是有益的。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    TangView()
}
