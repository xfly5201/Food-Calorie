import SwiftUI

struct DanbzView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日蛋白质摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("56克")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    蛋白质是构成身体组织的基本元素，参与几乎所有细胞功能。它们由氨基酸组成，某些氨基酸是人体无法自行合成的，必须通过饮食获取。成年人每天需要每公斤体重0.8克的蛋白质。这是为了满足大多数健康成年人的基本需求。
                    
                    过量摄入蛋白质可能增加肾脏负担，尤其是在已有肾脏疾病的人群中。
                    
                    摄入不足会导致肌肉质量下降，免疫系统功能受损，生长发育延迟（儿童）。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    DanbzView()
}
