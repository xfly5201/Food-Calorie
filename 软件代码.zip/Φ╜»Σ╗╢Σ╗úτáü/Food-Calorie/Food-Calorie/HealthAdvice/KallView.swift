import SwiftUI

struct KallView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日卡路里摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("2000 或 2500卡")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    卡路里是衡量食物能量的单位。身体需要能量来维持基本生命活动（基础代谢率）和日常活动。卡路里的需求量因个人而异，受年龄、性别、体重、身高和活动水平的影响。根据活动水平和个人目标，成年女性的推荐每日摄入卡路里大约为2000卡，而成年男性则为2500卡。适当的卡路里摄入有助于维持健康的体重和整体健康。
                    
                    摄入过多会导致体重增加、肥胖以及相关健康问题；
                    
                    摄入不足会导致体重下降、能量不足、营养不良。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    KallView()
}
