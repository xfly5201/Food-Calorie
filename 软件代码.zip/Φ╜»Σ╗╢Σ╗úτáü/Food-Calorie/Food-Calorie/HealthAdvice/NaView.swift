import SwiftUI

struct NaView: View {
    var body: some View {
           VStack(spacing: 20) {
               Spacer()
               
               Image(systemName: "flame.fill")
                   .resizable()
                   .scaledToFit()
                   .frame(width: 60, height: 60)
                   .foregroundColor(.orange)
               
               Text("每日钠摄入推荐")
                   .font(.system(size: 24, weight: .medium, design: .rounded))
                   .padding(.vertical)
               
               Text("<2300毫克")
                   .font(.system(size: 48, weight: .bold, design: .rounded))
                   .foregroundColor(.red)
               
               Text("""
                    钠是维持体液平衡和电解质平衡的关键矿物质，对神经和肌肉功能也很重要。维持体液平衡，参与神经传导和肌肉收缩。
                    
                    摄入过多会导致高血压、心脏病、中风等问题。
                    
                    
                    摄入不足会导致头晕、混乱、肌肉抽搐。
                    """)
                   .font(.system(size: 16, weight: .regular, design: .rounded))
                   .padding(.horizontal)
                   .multilineTextAlignment(.center)
                   .lineSpacing(5)
               
               Spacer()
           }
           .frame(maxWidth: .infinity, maxHeight: .infinity)
           .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom))
           .edgesIgnoringSafeArea(.all)
       }
}

#Preview {
    NaView()
}
