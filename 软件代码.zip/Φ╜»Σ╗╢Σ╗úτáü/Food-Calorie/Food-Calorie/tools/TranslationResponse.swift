import Foundation

struct TranslationResponse: Codable {
    struct TranslationResult: Codable {
        let src: String
        let dst: String
    }
    let from: String
    let to: String
    let trans_result: [TranslationResult]
}
