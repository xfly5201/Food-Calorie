import Foundation

struct NutritionResponse: Codable {
    var items: [FoodItem]
}
struct FoodItem: Codable {
    // 都是每100克的量
    var name: String //食物名称
    var calories: Double //食物的卡路里数
    var serving_size_g: Double //每份食物的重量（克），这里标准为100克
    var fat_total_g: Double //总脂肪含量
    var fat_saturated_g: Double //食物的饱和脂肪含量
    var protein_g: Double //食物的蛋白质含量
    var sodium_mg: Double //食物的钠含量（毫克
    var potassium_mg: Double //食物的钾含量（毫克）
    var cholesterol_mg: Double //食物的胆固醇含量（毫克）
    var carbohydrates_total_g: Double //食物的总碳水化合物含量
    var fiber_g: Double //食物的纤维含量
    var sugar_g: Double //食物的糖含量
}
