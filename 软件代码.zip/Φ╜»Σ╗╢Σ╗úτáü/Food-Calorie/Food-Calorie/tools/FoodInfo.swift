import Foundation

struct FoodInfo {
    var foodName: String = "" // 食物英文名
    var foodChineseName: String = "" // 食物中文名
    var foodCalories: Double = 0 // 食物卡路里
    var foodWeight: Double = 0 // 食物重量
    var foodFatTotal: Double = 0 // 食物总脂肪含量
    var foodFatSaturated: Double = 0 // 食物饱和脂肪含量
    var foodProtein: Double = 0 // 食物蛋白质含量
    var foodSodium: Double = 0 // 食物钠含量
    var foodPotassium: Double = 0 // 食物钾含量
    var foodCholesterol: Double = 0 // 食物胆固醇含量
    var foodCarbohydratesTotal: Double = 0 // 食物总碳水化合物含量
    var foodFiber: Double = 0 // 食物纤维含量
    var foodSugar: Double = 0 // 食物糖含量
}
