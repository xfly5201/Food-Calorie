import SwiftUI

@main
struct Food_CalorieApp: App {
    
    private let coreDataStack = CoreDataStack(modelName: "FoodCalorieModel")
    var body: some Scene {
        WindowGroup {
            ContentView()
                // 使得ContentView以及他的子视图都可以从环境里面获取访问数据库的入口
                .environment(\.managedObjectContext,coreDataStack.managedObjectContext) // 添加环境变量
                // 加入环境变量，让所有的子界面都可以调用这个coreDataStack
                .environmentObject(coreDataStack)
        }
    }
}
