//
//  test.swift
//  Food-Calorie
//
//  Created by 夏飞宇 on 2024/2/14.
//

import SwiftUI


struct test: View {
    @State private var isShowingImagePicker = false
    @State private var image: Image? = nil

    var body: some View {
        VStack {
            Spacer()
            
            if let image = image {
                image
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .shadow(radius: 10)
            } else {
                Text("点击下方按钮选择图片")
                    .font(.headline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Button(action: {
                self.isShowingImagePicker = true
            }) {
                HStack {
                    Image(systemName: "camera")
                    Text("选择照片")
                }
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding()
                .foregroundColor(.white)
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                .cornerRadius(40)
                .font(.headline)
            }
            .padding(.bottom, 20)
        }
        .padding()
        .navigationBarTitle("拍照识别", displayMode: .inline)
        .sheet(isPresented: $isShowingImagePicker) {
            ImagePickerView(image: self.$image)
        }
    }
}

struct ImagePickerView: UIViewControllerRepresentable {
    @Binding var image: Image?

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var parent: ImagePickerView

        init(_ parent: ImagePickerView) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = Image(uiImage: uiImage)
            }

            picker.dismiss(animated: true)
        }
    }
}




#Preview {
    test()
}
