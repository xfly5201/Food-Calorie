import coremltools as ct
from keras.models import load_model

# 加载 Keras 模型
my_model = load_model('model_trained.h5')

# 定义模型的输入，这里假设是 299x299x3 的 RGB 图像
input_image = ct.ImageType(shape=(1, 299, 299, 3), scale=1/255.0)

# 转换模型
coreml_model = ct.convert(my_model, inputs=[input_image])

# 保存 Core ML 模型
coreml_model.save('MyModel.mlpackage')


